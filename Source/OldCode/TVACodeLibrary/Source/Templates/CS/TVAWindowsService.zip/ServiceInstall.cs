﻿using System.ComponentModel;
using System.Configuration.Install;


namespace $safeprojectname$
{
    [RunInstaller(true)]
    public partial class ServiceInstall : Installer
    {
        public ServiceInstall()
        {
            InitializeComponent();
        }
    }
}
