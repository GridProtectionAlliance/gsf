﻿using System;
using System.ComponentModel;
using System.ServiceProcess;

namespace $safeprojectname$
{
    public partial class ServiceHost : ServiceBase
    {
        #region [ Constructors ]

        public ServiceHost()
            : base()
        {
            InitializeComponent();

            // Register event handlers.
            m_serviceHelper.ServiceStarted += ServiceHelper_ServiceStarted;
            m_serviceHelper.ServiceStopping += ServiceHelper_ServiceStopping;
        }

        public ServiceHost(IContainer container)
            : this()
        {
            if (container != null)
                container.Add(this);
        }

        #endregion

        #region [ Methods ]

        private void PrimaryProcess(string processName, object[] processArguments)
        {
            // TODO: Put code for primary process.
        }

        private void HeartbeatProcess(string processName, object[] processArguments)
        {
            // TODO: Put code for hearbeat process.
        }

        private void ServiceHelper_ServiceStarted(object sender, EventArgs e)
        {
            // TODO: Put initialization code here.
            m_serviceHelper.AddScheduledProcess(PrimaryProcess, "PrimaryProcess", "* * * * *");
            m_serviceHelper.AddScheduledProcess(HeartbeatProcess, "HeartbeatProcess", "* * * * *");
        }

        private void ServiceHelper_ServiceStopping(object sender, EventArgs e)
        {
            // TODO: Put clean-up code here.
        }

        #endregion
    }
}
